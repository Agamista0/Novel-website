<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/includes/footer.css">
    <title>Document</title>
</head>
<body>
<div class="footer">
       <div class="footer-links">
       <a href="">HOME</a>
        <a href="">CONTACT US</a>
        <a href="">Privacy</a>
       </div>
       <p>&copy; 2024 JADENOVELS. All rights reserved</p>

    </div>
</body>
</html>